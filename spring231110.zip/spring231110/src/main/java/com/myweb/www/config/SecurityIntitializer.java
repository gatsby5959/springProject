package com.myweb.www.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

//AbstractSecurityWebApplicationInitializer 상속받아야
//시큐리티 관련 필터들이 활성화 됨
//끝	

public class SecurityIntitializer extends AbstractSecurityWebApplicationInitializer {

	//끝	
}
